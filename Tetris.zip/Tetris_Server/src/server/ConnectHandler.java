package server;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.SocketException;
import java.util.Iterator;
import java.util.Map;

import jdbc.JDBC;
import users.UserData;
import users.OnlineUserIpAddr;

class ConnectHandler extends Thread {
	private JDBC jdbc;
	private Socket socket;
	private final static int messageLength = 1024;
	private BufferedInputStream messageBytes;
	private UserData data;

	public ConnectHandler(Socket socket, JDBC jdbc) {
		this.socket = socket;
		this.jdbc = jdbc;
	}

	@SuppressWarnings("rawtypes")
	public void getOnlinePlayers(PrintWriter printWriter) {
		// 遍历在线玩家哈希表发送在线玩家信息
		Iterator iterator = OnlineUserIpAddr.getUserIpList().entrySet().iterator();
		StringBuffer userId = new StringBuffer("userId,");
		while (iterator.hasNext()) {
			Map.Entry entry = (Map.Entry) iterator.next();

				userId.append("#"+entry.getKey());
		}
		printWriter.println(userId.toString());
		printWriter.flush();
		
	}

	@SuppressWarnings("rawtypes")
	public void newPlayerLogin() {
		// 遍历在线玩家哈希表发送玩家登录信息
		Iterator iterator = OnlineUserIpAddr.getUserIpList().entrySet().iterator();
		PrintWriter writer;
		while (iterator.hasNext()) {
			Map.Entry entry = (Map.Entry) iterator.next();
			try {
				writer = new PrintWriter(
						OnlineUserIpAddr.getPlayerSocketByIp(OnlineUserIpAddr.getPlayerIpById((String) entry.getKey()))
								.getOutputStream());
				writer.println("login," + data.getUserId());
				writer.flush();
				//writer.close();
			} catch (IOException e) {
				System.out.println("发送消息失败，建议重启服务器。。。");
				// e.printStackTrace();
			}

		}
	}

	@SuppressWarnings("rawtypes")
	public void newPlayerLogout(String userId) {
		// 遍历在线玩家哈希表发送玩家登出信息
		Iterator iterator = OnlineUserIpAddr.getUserIpList().entrySet().iterator();
		PrintWriter writer;
		while (iterator.hasNext()) {
			Map.Entry entry = (Map.Entry) iterator.next();
			try {
				writer = new PrintWriter(
						OnlineUserIpAddr.getPlayerSocketByIp(OnlineUserIpAddr.getPlayerIpById((String) entry.getKey()))
								.getOutputStream());
				writer.println("logout," + userId);
				writer.flush();
				//writer.close();
			} catch (IOException e) {
				System.out.println("发送消息失败，建议重启服务器。。。");
				// e.printStackTrace();
			}

		}
	}

	@Override
	public void run() {
		try {
			messageBytes = new BufferedInputStream(socket.getInputStream());
			byte[] bytes = new byte[messageLength];

			// 返回消息至客户端
			OutputStream out=socket.getOutputStream();
			PrintWriter printWriter = new PrintWriter(socket.getOutputStream());
			printWriter.println("welcome,欢迎来到Tetris！");
			printWriter.flush();
			// 接收客户端消息
			while (true) {
				bytes = new byte[messageLength];
				if(messageBytes.read(bytes) == 0) {
					continue;
				}
				String message = new String(bytes, "UTF-8");
				String[] messages = message.split(",");
				if (!message.trim().isEmpty() || !messages[0].trim().isEmpty()) {
					// 新用户注册
					if (messages.length == 3 && messages[0].equals("register")) {
						data = new UserData(messages[1], messages[2]);
						int result = jdbc.isUserExist(messages[1]);

						// ID占用检测
						if (result == 1) {
							// ID已被占用
							printWriter.println("registerFailed,用户名已被占用！");
							printWriter.flush();
						} else if (result == -1) {
							// 无法查询数据库
							System.out.println("用户名查重失败，请检查数据库连接！");
							printWriter.println("registerFailed,用户名查重失败，请稍后再试！");
							printWriter.flush();
						} else {
							// ID未被占用
							if (jdbc.register(data.getUserId(), data.getPassword().trim())) {
								printWriter.println("registerSuccessed,注册成功！");
								printWriter.flush();
								System.out.println("新用户注册：" + data.getUserId() + ";IP:"
										+ socket.getInetAddress().getHostAddress());
								// 同步玩家信息
								getOnlinePlayers(printWriter);
								newPlayerLogin();
								OnlineUserIpAddr.addPlayer(data, socket.getInetAddress().getHostName(), socket);
							}
						}
						
					}

					// 用户登录
					if (messages.length == 3 && messages[0].equals("login")) {
						data = new UserData(messages[1], messages[2]);
						int result = jdbc.login(messages[1], messages[2].trim());
						if (result == 1) {
							// 登录成功
							printWriter.println("loginSuccessed,登录成功！");
							printWriter.flush();
							// 同步玩家信息
							getOnlinePlayers(printWriter);
							newPlayerLogin();
							OnlineUserIpAddr.addPlayer(data, socket.getInetAddress().getHostName(), socket);
						} else if (result == 0) {
							// 密码错误
							printWriter.println("loginFailed,密码错误！");
							printWriter.flush();
						} else if (result == -2) {
							// 用户名不存在
							printWriter.println("loginFailed,用户名不存在！");
							printWriter.flush();
						} else if (result == -1) {
							// 无法查询数据库
							System.out.println("用户名查重失败，请检查数据库连接！");
							printWriter.println("loginFailed,用户名查重失败，请稍后再试！");
							printWriter.flush();
						}
					}

					// 提交&接受对战申请
					if (messages.length == 2
							&& (messages[0].equals("fightRequest") || messages[0].equals("receiveFightRequest"))) {
						// messages[1] == 对方的Id
						System.out.println(messages[0]+" "+messages[1]);
						if (OnlineUserIpAddr.isPlayerExist(messages[1].trim())) {
							PrintWriter writer = new PrintWriter(
									OnlineUserIpAddr.getPlayerSocketByIp(OnlineUserIpAddr.getPlayerIpById(messages[1].trim()))
											.getOutputStream());
							writer.println(messages[0].trim() + "," + data.getUserId().trim());
							writer.flush();
						} else {
							printWriter.println("sendRequestError,该玩家已离线！");
							printWriter.flush();
						}
					}
					
					

					// 开始对战
					if (messages.length == 3 && messages[0].equals("startFight")) {
						// messages[1] == 自己的Id
						// messages[2] == 对方的Id
						System.out.println("start:"+message);
						
						PrintWriter writer = new PrintWriter(OnlineUserIpAddr
								.getPlayerSocketByIp(OnlineUserIpAddr.getPlayerIpById(messages[2].trim())).getOutputStream());
						writer.println(messages[0].trim() + "," + messages[1].trim());
						writer.flush();
						//writer.close();
						printWriter.println(messages[0].trim() + "," + messages[2].trim());
						printWriter.flush();
					}

					// 对战数据
					if (messages.length == 4&&messages[0].equals("blockstop")) {
						System.out.println(messages[0]+messages[1]+messages[2]);
						PrintWriter writer = new PrintWriter(OnlineUserIpAddr
								.getPlayerSocketByIp(OnlineUserIpAddr.getPlayerIpById(messages[3].trim())).getOutputStream());
						writer.println(messages[0].trim() + "," + messages[1].trim()+","+messages[2]);
						writer.flush();
					}

					if (messages.length == 5&&messages[0].equals("blockremove")) {
						//message[0] blockremove
						//message[1] 移除的行数
						//message[2] 对方ID
						//message[3] 随机的空缺位置
						//message[4] 开始移除的列
						System.out.println(messages[0]+messages[1]+messages[2]+messages[3]+messages[4]);
						PrintWriter writer = new PrintWriter(OnlineUserIpAddr
								.getPlayerSocketByIp(OnlineUserIpAddr.getPlayerIpById(messages[4].trim())).getOutputStream());
						writer.println(messages[0].trim() + "," + messages[1].trim()+","+messages[2]+","+messages[3]);
						writer.flush();
					}
					if (messages.length == 2&&messages[0].equals("win")) {
						System.out.println(messages[0]+messages[1]);
						PrintWriter writer = new PrintWriter(OnlineUserIpAddr
								.getPlayerSocketByIp(OnlineUserIpAddr.getPlayerIpById(messages[1].trim())).getOutputStream());
						writer.println("win,"+messages[1]);
						writer.flush();
					}
					

				} else {
					System.out.println("Error message:" + message.trim());
				}
			}
		} catch (SocketException se) {
			// 客户端断开连接
			String Ip = socket.getInetAddress().getHostName();
			System.out.println(Ip + " 已断开连接！");
			if (OnlineUserIpAddr.isIpExist(Ip)){
				String userId = OnlineUserIpAddr.getPlayerIdByIp(Ip);
				if (OnlineUserIpAddr.isIpExist(userId)) {
					OnlineUserIpAddr.removePlayer(userId);
				}
				newPlayerLogout(userId);
			}
		} catch (IOException e) {
			// 服务器异常
			System.out.println("接收报文失败！");
		}
	}
}