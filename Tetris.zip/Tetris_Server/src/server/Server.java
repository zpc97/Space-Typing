package server;

import java.io.IOException;
import java.net.BindException;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.SQLException;

import jdbc.JDBC;

public class Server {
	private static final int port = 10086;
	private JDBC jdbc;

	private Runnable startServer;

	public void startUp() {
		try {
			jdbc = new JDBC();
		} catch (SQLException e) {
			System.out.println("连接数据库失败，无法启动服务器！");
		}
		startServer = new Runnable() {
			@Override
			public void run() {
				ServerSocket serverSocket = null;
				try {
					serverSocket = new ServerSocket(port);
					System.out.println("服务器已启动！(使用端口：" + port + ")");
					while (true) {
						try {
							while (true) {
								Socket socket = serverSocket.accept();
								System.out.println(socket.getInetAddress().getHostAddress() + " 已接入！");
								new ConnectHandler(socket, jdbc).start();
							}
						} catch (IOException e1) {
							if (serverSocket != null) {
								try {
									serverSocket.close();
									break;
								} catch (IOException e2) {
									System.out.println("服务器异常！");
								}
								serverSocket = null;
							}
						}
					}
				} catch (BindException e) {
					System.out.println("服务器端口被占用！");
				} catch (IOException e) {
					System.out.println("初始化服务器失败！");
				}
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					System.out.println("服务器异常！");
				}
			}
		};
		new Thread(startServer, "WeChat").start();
	}

	public static void main(String[] args) {
		new Server().startUp();
	}
}