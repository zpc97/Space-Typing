package client;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.ConnectException;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;

public class WeChatClient {

	public static void main(String[] args) {

		// localhost
		// 10.16.24.131
		String Ip = "192.168.43.21";

		try {
			Socket socket = new Socket(Ip, 10086);

			// 获取服务器消息
			Runnable receiveMessage = new Runnable() {

				@Override
				public void run() {
					final int messageLength = 1024;
					BufferedInputStream messageBytes;
					try {
						messageBytes = new BufferedInputStream(socket.getInputStream());
						byte[] bytes;
						while (true) {
							bytes = new byte[messageLength];
							messageBytes.read(bytes);
							String message = new String(bytes, "UTF-8");
							String[] messages = message.split(",");
							if (messages.length > 1) {
								for (int i = 0; i < messages.length; i++) {
									System.out.println(messages[i].trim());
								}
							} else {
								System.out.println("ErrorMessage:" + message.trim());
							}
						}
					} catch (SocketException e) {
						System.out.println("与服务器断开连接！");
						try {
							socket.close();
							System.gc();
						} catch (IOException e1) {
							System.out.println("程序异常！");
							System.gc();
						}
						System.exit(0);
					} catch (IOException e) {
						System.out.println("获取消息失败！");
					}
				}
			};
			new Thread(receiveMessage, "接收服务器消息").start();

			// 发送信息测试
			Runnable sendMessageTest = new Runnable() {
				private final int messageLength = 1024;
				private InputStream inputStream;
				private PrintWriter printWriter = new PrintWriter(socket.getOutputStream());

				@Override
				public void run() {
					try {
						while (true) {
							byte[] bytes = new byte[messageLength];
							inputStream = System.in;
							inputStream.read(bytes);
							printWriter.write(new String(bytes, "UTF-8"));
							printWriter.flush();
						}
					} catch (IOException e) {
						System.out.println("发送失败！");
					}
				}
			};
			new Thread(sendMessageTest, "发送消息至服务器").start();

		} catch (ConnectException e) {
			System.out.println("丢失服务器！");
		} catch (UnknownHostException e) {
			System.out.println("无法找到服务器！请检查IP！");
		} catch (IOException e) {
			System.out.println("连接服务器失败！");
		}
	}
}