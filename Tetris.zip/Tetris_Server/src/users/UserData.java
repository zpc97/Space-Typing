package users;

public class UserData {
	private String userId;// 唯一用户名
	private String password;// 密码
	// 待补充……

	// 构造方法
	public UserData(String userId, String password) {
		this.userId = userId;
		this.password = password;
	}

	// getter
	public String getUserId() {
		return userId;
	}

	public String getPassword() {
		return password;
	}
}