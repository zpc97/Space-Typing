package users;

import java.net.Socket;
import java.util.Hashtable;

public class OnlineUserIpAddr {
	
	
	// userIp与UserData哈希表
	private static Hashtable<String, UserData> userList = new Hashtable<String, UserData>();
	private static Hashtable<UserData, String> IpList = new Hashtable<UserData, String>();

	// UserData与userId哈希表
	private static Hashtable<UserData, String> IdList = new Hashtable<UserData, String>();
	private static Hashtable<String, UserData> dataList = new Hashtable<String, UserData>();
	
	//UserIp与Socket哈希表
	private static Hashtable<String, Socket> socketList = new Hashtable<String, Socket>();

	// UserIp与userId哈希表
	public static Hashtable<String, String> userIpList = new Hashtable<String, String>();
	
	public static Hashtable<String, String> getUserIpList(){
		return userIpList;
	}
	
	public static boolean isIpExist(String Ip) {
		return userList.get(Ip) != null;
	}
	
	public static boolean isuserIdExist(String userId) {
		return userIpList.get(userId) != null;
	}
	
	public static boolean isPlayerExist(String userId) {
		return dataList.get(userId) != null;
	}

	public static void addPlayer(UserData userData, String Ip, Socket socket) {
		userList.put(Ip, userData);
		IpList.put(userData, Ip);
		IdList.put(userData, userData.getUserId());
		dataList.put(userData.getUserId(), userData);
		userIpList.put(userData.getUserId(), Ip);
		socketList.put(Ip, socket);
	}

	public static void removePlayer(String userId) {
		userIpList.remove(userId);
		socketList.remove(IpList.get(dataList.get(userId)));
		IpList.remove(userList.get(dataList.get(userId)));
		IdList.remove(userList.get(dataList.get(userId)));
		userList.remove(dataList.get(userId));
		dataList.remove(userId);
	}

	public static String getPlayerIdByIp(String Ip) {
		return userList.get(Ip).getUserId();
	}

	public static String getPlayerIpById(String userId) {
		return IpList.get(dataList.get(userId));
	}

	public static String getPlayerIpByData(UserData data) {
		return IpList.get(data);
	}
	
	public static Socket getPlayerSocketByIp(String Ip) {
		return socketList.get(Ip);
	}
}
