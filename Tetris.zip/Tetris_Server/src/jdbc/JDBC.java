package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBC {
	public static String IP = "localhost:1433";
	private String url = "jdbc:sqlserver://" + IP + ";DatabaseName=Tetris;";
	private Connection connection;
	private Statement statement;
	private ResultSet resultSet;

	// 初始化数据库
	public JDBC() throws SQLException {
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		} catch (ClassNotFoundException e) {
			System.out.println("数据库驱动出错！");
			e.printStackTrace();
		}
		connection = DriverManager.getConnection(url, "sa", "zpc534324239");
		statement = connection.createStatement();
	}

	// 检测Id是否被占用
	public int isUserExist(String userId) {
		String sql = "SELECT * FROM Users_Table Where UserId = " + "'" + userId + "';";
		try {
			resultSet = statement.executeQuery(sql);
			if (resultSet.next()) {
				// 该Id已存在
				return 1;
			} else {
				return 0;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return -1;
		}
	}

	// 用户登录
	public int login(String userId, String password) {
		String sql = "SELECT * FROM Users_Table Where UserId = " + "'" + userId + "';";
		try {
			resultSet = statement.executeQuery(sql);
			if (resultSet.next()) {
				if (resultSet.getString("Password").trim().equals(password)) {
					return 1;
				} else {
					// 密码错误
					return 0;
				}
			} else {
				// 未找到该Id
				return -2;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return -1;
		}
	}

	public boolean register(String userId, String password) {
		String sql = "SET NOCOUNT ON " + "INSERT INTO Users_Table VALUES('" + userId + "','" + password + "');"
				+ "SET NOCOUNT OFF";
		try {
			statement.execute(sql);
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
}